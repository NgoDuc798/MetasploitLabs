#!/bin/bash
sudo systemctl restart redis
